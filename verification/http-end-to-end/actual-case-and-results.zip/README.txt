OpenCFD OpenFOAM v2312 fixed-hull free-surface case

Run: bash Allrun
Use only the pinned distribution/version. The script runs surface/mesh checks and stops on failure. It never deletes prior data. Use a fresh case directory for each variant.

Geometry is the actual original STL transformed from mm to m and shifted vertically by -draft. Inflow is negative X; towing drag is -Fx from hullForces, not the magnitude of an arbitrary component. Moment reference is the supplied measured CG in the shifted frame.

A successful solver exit is not a validation certificate. Discard startup and establish stationarity, phase/mass balance, surface/mesh quality and mesh/time/domain convergence before comparing designs. The coarse mesh is a smoke test. The laminar flow and 90-degree wetting assumptions require physical sensitivity checks. Fixed hull cannot predict roll motion.

See manifest.json for exact protocol, load, geometry hash, dimensions and assumptions.
