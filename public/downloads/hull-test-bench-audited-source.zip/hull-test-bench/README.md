# Hull Test Bench

A simplified version of the Arova Ship Test Bench for testing your own hull designs.
Upload STL files, and every hull is put through the same programme in a virtual model tank:
3 weights, each in calm water and 3 seas. You get drag, roll stability and buoyancy for
each case, a leaderboard across all uploaded hulls, and an Excel file of the results.

## Run

```sh
npm install
npm run dev      # http://localhost:5173
npm run build    # dist/ (and dist/hull-test-bench.html, a single file that opens from disk)
npm test         # physics checks
```

`npx tsx scripts/make-samples.ts samples` writes a few sample STL files.

## Using it

1. **Add STL** (or drop files on the tank). Several files can be added at once.
2. Check the model sits right: deck up, bow at the orange arrow. If not, use **Flip**,
   **Roll 90°** or **Turn 90°**. Set the STL unit if the size shown is wrong.
3. Pick a weight in the panel and a water condition in the table to play it in the tank.
4. **Download Excel** exports every model, weight and sea.

## Test conditions

Everything is Froude-scaled from the original app's 120 m demo ferry to the 220 mm size limit
(scale 1:545), so all models meet identical conditions. Change them under *Test conditions*.

| | Model scale | Full size |
| --- | --- | --- |
| Empty | 22.5 g | lightship 3743 t |
| Loaded | 28 g | + luggage 20 t, fuel/water 400 t, cargo 500 t |
| Overloaded | 33.5 g | + double luggage, fuel and cargo |
| Moderate sea | 3.7 mm, 0.36 s | 2 m |
| Rough sea | 7.3 mm, 0.45 s | 4 m |
| Very rough sea | 11 mm, 0.54 s | 6 m |
| Speed | 0.40 m/s | 18 kn |

Tank (simulation boundary): 2.2 x 1.1 x 0.55 m. Results are calculated for open, deep water;
the tank is sized so walls and floor would not change them (depth > half the longest wave,
blockage < 0.5 %, depth Froude number < 0.5, wake reflection lands far behind the hull).

## How results are calculated

| Result | Method | File |
| --- | --- | --- |
| Hull shape | STL rasterised into vertical columns; outer shape sealed at the deck | `src/engine/hull.ts` |
| Orientation | longest axis = length, mirror-symmetric axis = beam, finer end = bow | `src/engine/orient.ts` |
| Draft, freeboard, buoyancy, max load | buoyancy = density x g x submerged volume | `src/engine/hydrostatics.ts` |
| Roll stability | righting-arm (GZ) curve 0-90 deg at constant weight, both sides | `src/engine/hydrostatics.ts` |
| Calm-water drag | Holtrop & Mennen 1984 (ported from vessel.js), ITTC-57 friction | `src/engine/drag.ts` |
| Added drag in waves | STAWAVE-2 (ITTC 7.5-04-01-01.1) summed over the sea's components | `src/engine/drag.ts` |
| Roll, pitch, heave, buoyancy in waves | time simulation in an irregular sea (Bretschneider) | `src/engine/sim.ts` |
| Leaderboard | best in each of drag / roll / max load = 100 points, total = average | `src/engine/analyze.ts` |

Assumptions: fresh water; centre of gravity at the centre of the model's volume (changeable);
load placed so the ship floats level; hull watertight up to the deck edge.

Buoyancy and stability follow directly from the geometry and are checked against hand
calculations for a box hull (`tests/engine.test.ts`). The drag code reproduces the worked
example from Holtrop & Mennen's paper. Drag and wave results are engineering estimates, not
CFD: use them to compare designs under identical conditions, not as absolute predictions.

## Credits

Built on the Arova Ship Test Bench (conventions, sea states, reference ferry, visual style).
The Holtrop resistance formulas are ported from vessel.js (MIT licence, shiplab/vesseljs).
