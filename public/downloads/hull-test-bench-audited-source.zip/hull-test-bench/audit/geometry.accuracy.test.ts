import { afterAll, describe, expect, it } from "vitest";
import { parseSTL, writeSTL } from "../src/engine/stl";
import { boxHull, exampleHull } from "../src/engine/example";
import { analyzeModel } from "../src/engine/analyze";
import { defaultConditions } from "../src/engine/conditions";
import { buildColumns, gridSize } from "../src/engine/hull";
import { IDENTITY, ROLL90, TURN90, autoOrient, guessUnitScale, mul, place, type Mat3 } from "../src/engine/orient";
import { benchmark, check, finish } from "./harness";

const category = "Geometry, STL and orientation";
const mmToM = (t: Float32Array) => t.map(v => v / 1000);
const rejects = (f: () => unknown) => { try { f(); return false; } catch { return true; } };
const textBuffer = (s: string) => new TextEncoder().encode(s).buffer as ArrayBuffer;
const ascii = (t: Float32Array) => "solid independent_fixture\n" + Array.from({length:t.length/9},(_,i) => "facet normal 0 0 0\nouter loop\n" + Array.from({length:3},(_,j)=>"vertex "+Array.from(t.slice(i*9+j*3,i*9+j*3+3)).map(v=>v.toExponential(8)).join(" ")).join("\n") + "\nendloop\nendfacet").join("\n") + "\nendsolid independent_fixture";

function combined(...pieces: Float32Array[]) {
  const out = new Float32Array(pieces.reduce((n,p)=>n+p.length,0));
  let offset=0;for(const p of pieces){out.set(p,offset);offset+=p.length;}return out;
}
function shifted(t:Float32Array,dx=0,dy=0,dz=0) {
  return t.map((v,i)=>v+[dx,dy,dz][i%3]);
}
/** Independent 200x60x40mm box wall solid, 2mm bottom and side walls, open top. */
function basin(L=200,B=60,D=40,wall=2) {
  const outside=boxHull(L,B,D),inside=shifted(boxHull(L-2*wall,B-2*wall,D-wall),wall,0,wall);
  // Both are open at the common top; the annular rim joins outer and inner skins.
  const exterior=combined(outside.slice(0,18),outside.slice(36));
  for(let i=0;i<exterior.length;i+=9)for(let j=0;j<3;j++){const v=exterior[i+3+j];exterior[i+3+j]=exterior[i+6+j];exterior[i+6+j]=v;}
  const interior=combined(inside.slice(0,18),inside.slice(36));
  const outer=[[0,-B/2,D],[L,-B/2,D],[L,B/2,D],[0,B/2,D]];
  const inner=[[wall,-B/2+wall,D],[L-wall,-B/2+wall,D],[L-wall,B/2-wall,D],[wall,B/2-wall,D]];
  const rim:number[]=[];
  for(let i=0;i<4;i++){const j=(i+1)%4;rim.push(...outer[i],...outer[j],...inner[j],...outer[i],...inner[j],...inner[i]);}
  return combined(exterior,interior,new Float32Array(rim));
}
/** Exterior triangular cross-section: keel at y=0,z=0 and two rim points z=D. */
function vee(L:number,B:number,D:number,closed:boolean) {
  const k0=[0,0,0], l0=[0,-B/2,D], r0=[0,B/2,D];
  const k1=[L,0,0], l1=[L,-B/2,D], r1=[L,B/2,D];
  const out:number[]=[];
  const tri=(a:number[],b:number[],c:number[])=>out.push(...a,...b,...c);
  const quad=(a:number[],b:number[],c:number[],d:number[])=>{tri(a,b,c);tri(a,c,d);};
  quad(k0,k1,l1,l0);quad(k0,r0,r1,k1);
  tri(k0,l0,r0);tri(k1,r1,l1);
  if(closed)quad(l0,l1,r1,r0);
  return new Float32Array(out);
}
const volume = (t:Float32Array,h=.001) => buildColumns(mmToM(t),h).volume;

function rotations():Mat3[] {
  const found=new Map<string,Mat3>([[IDENTITY.join(','),IDENTITY]]),queue=[IDENTITY];
  for(let i=0;i<queue.length;i++)for(const step of [ROLL90,TURN90]) {
    const m=mul(step,queue[i]),key=m.join(',');if(!found.has(key)){found.set(key,m);queue.push(m);}
  }
  return [...found.values()];
}
const axisKey = (m:Mat3) => {const v=[m[2],m[5],m[8]],i=v.findIndex(x=>Math.abs(x)===1);return `${v[i]>0?'+':'-'}${'XYZ'[i]}`;};
const keelMetric=(t:Float32Array)=>{let sum=0,n=0;for(let i=0;i<t.length;i+=3)if(Math.abs(t[i+1])<.1){sum+=t[i+2];n++;}return sum/n;};

afterAll(()=>finish('geometry'));

describe('Independent uploaded-source geometry accuracy audit',()=>{
  it('A031 binary STL round trip preserves all finite vertices',()=>{
    const fixture=boxHull(203.4,61.7,40.2),actual=parseSTL(writeSTL(fixture));
    const error=Math.max(...Array.from(actual,(v,i)=>Math.abs(v-fixture[i])));
    expect(benchmark({id:'A031',category,name:'Binary STL finite-coordinate round trip',actual:error,expected:0,absTolerance:1e-6,unit:'mm',note:'Exact same Float32 coordinates should survive binary encoding.'})).toBe(true);
  });
  it('A032 ASCII STL with scientific notation preserves vertices',()=>{
    const fixture=boxHull(203.4,61.7,40.2),actual=parseSTL(textBuffer(ascii(fixture)));
    const error=Math.max(...Array.from(actual,(v,i)=>Math.abs(v-fixture[i])));
    expect(benchmark({id:'A032',category,name:'ASCII STL scientific notation',actual:error,expected:0,absTolerance:2e-5,unit:'mm',note:'Input uses signed scientific notation and explicit facets.'})).toBe(true);
  });
  it('A033 binary NaN coordinate is rejected',()=>{
    const b=writeSTL(boxHull(200,60,40));new DataView(b).setFloat32(96,NaN,true);
    const actual=rejects(()=>parseSTL(b));expect(check({id:'A033',category,name:'Reject nonfinite NaN STL coordinates',expected:true,actual,passed:actual,severity:'high'})).toBe(true);
  });
  it('A034 binary infinite coordinate is rejected',()=>{
    const b=writeSTL(boxHull(200,60,40));new DataView(b).setFloat32(96,Infinity,true);
    const actual=rejects(()=>parseSTL(b));expect(check({id:'A034',category,name:'Reject infinite STL coordinates',expected:true,actual,passed:actual,severity:'high'})).toBe(true);
  });
  it('A035 truncated binary declared facet count is rejected',()=>{
    const b=writeSTL(boxHull(200,60,40)).slice(0,-50),actual=rejects(()=>parseSTL(b));
    expect(check({id:'A035',category,name:'Reject binary STL missing a declared triangle',expected:true,actual,passed:actual,severity:'high',note:'One complete triangle is absent although header still declares 12. Accepting it silently can alter the water-excluding shape.'})).toBe(true);
  });
  it('A036 ASCII incomplete extra triangle is rejected instead of silently removed',()=>{
    const valid=ascii(boxHull(200,60,40));
    const malformed=valid.replace('endsolid independent_fixture','facet normal 0 0 0\nouter loop\nvertex 0 0 0\nvertex 100 0 0\nendloop\nendfacet\nendsolid independent_fixture');
    const actual=rejects(()=>parseSTL(textBuffer(malformed)));
    expect(check({id:'A036',category,name:'Reject incomplete ASCII facet',expected:true,actual,passed:actual,severity:'medium',note:'Final facet has two vertices; source reader truncates leftover coordinates.'})).toBe(true);
  });
  it('A037 analysis rejects planar geometry before producing hydrodynamics',async()=>{
    const fixture=boxHull(200,60,0);let actual=false;
    try{await analyzeModel(fixture,defaultConditions());}catch{actual=true;}
    expect(check({id:'A037',category,name:'Reject zero-depth hull in analysis',expected:true,actual,passed:actual,severity:'high'})).toBe(true);
  });
  for(const [id,unit,L,expected] of [
    ['A038','metres',.2,1000],['A039','centimetres',20,10],['A040','small millimetres',20,1],
  ] as const)it(`${id} explicit known ${unit} fixture and guessed unit`,()=>{
    const actual=guessUnitScale(boxHull(L,L*.3,L*.2));
    expect(benchmark({id,category,name:`Unit guess for known ${unit} input`,actual,expected,absTolerance:0,unit:'mm per source unit',severity:id==='A040'?'medium':'info',note:id==='A040'?'A 20mm model is silently guessed to be centimetres. Units are intrinsically ambiguous in STL; confirmation is essential.':'Known physical unit used only by the independent fixture.'})).toBe(true);
  });
  const allRotations=rotations(),base=exampleHull(),baseline=keelMetric(place(base,IDENTITY).tris);
  for(const [index,key] of ['+X','-X','+Y','-Y','+Z','-Z'].entries())it(`A0${41+index} recover known physical keel with input up ${key}`,()=>{
    const group=allRotations.filter(m=>axisKey(m)===key);
    const errors=group.map(m=>{const raw=place(base,m).tris;return Math.abs(keelMetric(place(raw,autoOrient(raw)).tris)-baseline);});
    const actual=Math.max(...errors);
    expect(benchmark({id:`A0${41+index}`,category,name:`Correct upright orientation: original +Z mapped to ${key}`,actual,expected:0,absTolerance:.1,unit:'mm keel-metric error',severity:'high',note:`Four distinct bow directions tested in this group; ${allRotations.length} total proper cube rotations. Comparing an identifiable keel feature, not bounding-box dimensions. Errors: ${errors.map(x=>x.toFixed(4)).join(', ')}.`})).toBe(true);
  });
  it('A047 fine-grid off-grid box volume agrees with exact dimensions within 1%',()=>{
    const L=220,B=37,D=16.5,h=gridSize(L/1000,B/1000,256,60000),actual=volume(boxHull(L,B,D),h),expected=L*B*D*1e-9;
    expect(benchmark({id:'A047',category,name:'Off-grid rectangular envelope volume at app default resolution',actual,expected,relTolerance:.01,unit:'m³',note:`Uses the actual analysis gridSize(L,B,256,60000), h=${h}m. Box has the source example's220×37×16.5mm dimensions; transverse width is not an integer number of cells.`})).toBe(true);
  });
  it('A048 closed V-prism coarse-grid volume matches independent triangular area',()=>{
    const actual=volume(vee(200,60,40,true),.001),expected=.2*.06*.04/2;
    expect(benchmark({id:'A048',category,name:'Closed V-section prism volume at 1mm grid',actual,expected,relTolerance:.01,unit:'m³',note:'Exact cross-section area is B×D/2.'})).toBe(true);
  });
  it('A049 closed V-prism fine-grid volume matches independent triangular area',()=>{
    const actual=volume(vee(200,60,40,true),.0005),expected=.2*.06*.04/2;
    expect(benchmark({id:'A049',category,name:'Closed V-section prism volume at 0.5mm grid',actual,expected,relTolerance:.0025,unit:'m³',note:'Refinement case with predeclared 0.25% volume tolerance.'})).toBe(true);
  });
  it('A050 closed envelope volume is invariant under triangle winding reversal',()=>{
    const fixture=vee(200,60,40,true),reversed=fixture.slice();
    for(let i=0;i<fixture.length;i+=9)for(let j=0;j<3;j++){reversed[i+3+j]=fixture[i+6+j];reversed[i+6+j]=fixture[i+3+j];}
    expect(benchmark({id:'A050',category,name:'Winding invariance of rasterized envelope volume',actual:volume(reversed),expected:volume(fixture),relTolerance:1e-9,unit:'m³'})).toBe(true);
  });
  it('A051 open flat-bottom box is sealed to its actual rim rather than collapsed',()=>{
    const closed=boxHull(200,60,40),open=combined(closed.slice(0,18),closed.slice(36));
    expect(benchmark({id:'A051',category,name:'Open flat-bottom outer skin displacement',actual:volume(open),expected:.2*.06*.04,relTolerance:.01,unit:'m³',severity:'critical',note:'Remove only the deck from a box; bottom, sides and end walls remain. The real dry volume to the 40mm rim is 480cm³.'})).toBe(true);
  });
  it('A052 thin-wall printed basin measures dry displacement rather than plastic volume',()=>{
    expect(benchmark({id:'A052',category,name:'Open printed basin exterior displacement',actual:volume(basin()),expected:.2*.06*.04,relTolerance:.015,unit:'m³',severity:'critical',note:'The open boat is kept dry. STL consists of the 2mm printed base/walls; maximum dry outer displacement is 480cm³, not the material volume.'})).toBe(true);
  });
  it('A053 disconnected vertical solids do not count the intervening water as hull',()=>{
    const fixture=combined(boxHull(100,40,10),shifted(boxHull(100,40,10),0,0,20));
    expect(benchmark({id:'A053',category,name:'Vertically separated closed shells preserve water gap',actual:volume(fixture),expected:2*.1*.04*.01,relTolerance:.01,unit:'m³',severity:'high',note:'Two closed pontoons occupy z=0–10mm and20–30mm. The open10mm water gap must not become displacement; simple min/max columns bridge it.'})).toBe(true);
  });
  it('A054 separated catamaran pontoons do not fill the transverse channel',()=>{
    const fixture=combined(shifted(boxHull(200,20,40),0,-30),shifted(boxHull(200,20,40),0,30));
    expect(benchmark({id:'A054',category,name:'Side-by-side catamaran displacement',actual:volume(fixture),expected:2*.2*.02*.04,relTolerance:.01,unit:'m³',note:'Two20mm beams separated by a40mm open channel. Valid case for single-interval vertical columns.'})).toBe(true);
  });
  it('A055 open V-prism rim closure uses true rim height within 1%',()=>{
    expect(benchmark({id:'A055',category,name:'Open V-section prism displacement',actual:volume(vee(200,60,40,false)),expected:.2*.06*.04/2,relTolerance:.01,unit:'m³',severity:'high',note:'Removing the known flat deck must not lower the original40mm rim. Source infers rim from sampled cell centres, introducing capacity bias.'})).toBe(true);
  });
});
