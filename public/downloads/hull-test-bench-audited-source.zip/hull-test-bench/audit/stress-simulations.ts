/** Stress reliability only. These cases contain no wave-tank ground truth. */
import { mkdirSync, writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { boxHull, exampleHull } from '../src/engine/example';
import { IDENTITY, place } from '../src/engine/orient';
import { buildColumns, gridSize } from '../src/engine/hull';
import { floatUpright, maxLoadVolume } from '../src/engine/hydrostatics';
import { G, RHO, defaultConditions } from '../src/engine/conditions';
import { makeSetup, simulate } from '../src/engine/sim';

const specifications=[
  {name:'Box 200×60×40 mm',triangles:boxHull(200,60,40)},
  {name:'Wide box 200×90×35 mm',triangles:boxHull(200,90,35)},
  {name:'Tall narrow box 200×30×60 mm',triangles:boxHull(200,30,60)},
  {name:'Ferry 220×37×16.5 mm',triangles:exampleHull(220,37,16.5)},
  {name:'Wide ferry 180×80×35 mm',triangles:exampleHull(180,80,35)},
];
const fractions=[.05,.15,.3,.5,.7];
const conditions=defaultConditions();
const waters=[{label:'Calm',heightMm:0,periodS:.45},...conditions.waves];
const rows:Record<string,unknown>[]=[];
let count=0;const started=performance.now();
for(const spec of specifications) {
  const p=place(spec.triangles,IDENTITY),[Lmm,Bmm,Dmm]=p.size;
  const L=Lmm*.001,B=Bmm*.001,D=Dmm*.001;
  const h=gridSize(L,B,110,5000);
  const cols=buildColumns(p.tris.map(v=>v*.001),h);
  const maxVolume=maxLoadVolume(cols);
  for(const fraction of fractions) {
    const mass=maxVolume*RHO*fraction;
    const up=floatUpright(cols,mass/RHO);
    if(!up)throw new Error('Unexpected nonfloating stress fixture');
    const KG=.5*D,GM=up.zB+up.BMt-KG;
    const setup=makeSetup(cols,mass,KG,RHO,G,{Awp:up.Awp,xF:up.xF,IL:up.IL,GM,stationBeam:up.stationBeam},conditions.rollDamping);
    if(!setup)throw new Error('Unexpected null simulation setup');
    for(const water of waters) {
      const t=performance.now();
      const r=simulate(setup,water.heightMm*.001,water.periodS,true,0,40);
      let traceFinite=true,firstCapsizeIndex:number|null=null;
      for(let j=0;j<r.steps;j++) {
        if(![r.heave[j],r.roll[j],r.pitch[j]].every(Number.isFinite))traceFinite=false;
        if(firstCapsizeIndex===null&&Math.cos(r.roll[j])*Math.cos(r.pitch[j])<.05)firstCapsizeIndex=j;
      }
      const scalarValues=[r.dt,r.maxRollDeg,r.maxPitchDeg,r.maxHeave,r.buoyMin,r.buoyMax,r.minClearance];
      const scalarsFinite=scalarValues.every(Number.isFinite);
      const requestedDurationS=40*water.periodS,nominalDurationS=r.steps*r.dt;
      const measuredWindowStartS=5*water.periodS;
      const measurementReached=(firstCapsizeIndex===null?r.steps:firstCapsizeIndex)*r.dt>=measuredWindowStartS;
      const forceLimitN=cols.volume*RHO*G;
      const forceBoundsPhysical=r.buoyMin>=-1e-10&&r.buoyMax<=forceLimitN*(1+1e-9);
      const staticResidual=Math.abs(RHO*G*up.V-mass*G)/(mass*G);
      count++;
      const record={
        id:`S${String(count).padStart(3,'0')}`,hull:spec.name,capacityFraction:fraction,
        massG:mass*1000,water:water.label,significantWaveHeightMm:water.heightMm,peakPeriodS:water.periodS,
        heading:'beam',speedMps:0,gridHMetres:h,gridColumns:cols.n,
        KGmm:KG*1000,initialGMmm:GM*1000,initiallyStaticallyStable:GM>0,
        staticRelativeForceResidual:staticResidual,
        dtS:r.dt,allocatedSteps:r.steps,requestedDurationS,nominalAllocatedDurationS:nominalDurationS,
        durationCapReached:r.steps===30000&&nominalDurationS+r.dt<requestedDurationS,
        measuredWindowStartS:measuredWindowStartS,measurementReached,
        firstCapsizeTimeS:firstCapsizeIndex===null?null:firstCapsizeIndex*r.dt,
        finiteTraces:traceFinite,finiteStatistics:scalarsFinite,forceWithinDisplacementBounds:forceBoundsPhysical,
        maxRollDeg:r.maxRollDeg,maxPitchDeg:r.maxPitchDeg,maxHeaveMm:r.maxHeave*1000,
        buoyancyMinN:r.buoyMin,buoyancyMaxN:r.buoyMax,minDeckClearanceMm:r.minClearance*1000,
        capsized:r.capsized,wetDeck:r.minClearance<=0,
        runtimeMs:performance.now()-t,
        note:r.capsized?'Run terminates at capsize; allocated arrays repeat the final pose. Reported extrema may have no post-startup samples.':'No assertion of physical motion accuracy; finite output and numerical guard checks only.',
      };
      rows.push(record);
      if(count<=5||count%10===0)console.log(JSON.stringify({completed:count,runtimeMs:record.runtimeMs,totalSeconds:(performance.now()-started)/1000}));
      if(count===5&&(performance.now()-started)/1000>30)throw new Error('Stress suite exceeded timing budget after first five cases');
    }
  }
}
const summary={
  cases:rows.length,
  finiteTraces:rows.filter(r=>r.finiteTraces).length,
  finiteStatistics:rows.filter(r=>r.finiteStatistics).length,
  displacementForceBoundsSatisfied:rows.filter(r=>r.forceWithinDisplacementBounds).length,
  durationCaps:rows.filter(r=>r.durationCapReached).length,
  initiallyUnstable:rows.filter(r=>!r.initiallyStaticallyStable).length,
  capsizes:rows.filter(r=>r.capsized).length,
  wetDeck:rows.filter(r=>r.wetDeck).length,
  noPostStartupMeasurement:rows.filter(r=>!r.measurementReached).length,
  maximumStaticRelativeForceResidual:Math.max(...rows.map(r=>r.staticRelativeForceResidual as number)),
  totalRuntimeSeconds:(performance.now()-started)/1000,
};
mkdirSync('audit/results',{recursive:true});
writeFileSync('audit/results/stress-simulations.json',JSON.stringify({
  source:'Uploaded hull-test-bench-source.zip only; production source unchanged',
  purpose:'100 actual production-resolution stress simulations. Numerical reliability, not physical validation.',
  design:'5 geometries ×5 fractions of reconstructed capacity ×(calm+3 default wave presets);40peakperiods;beamwaves;dynamicgridSize(110,5000);KG=50%depth.',
  limitations:['No measured wave/force ground truth.','Only beam waves, no head-wave drag or pitch validation.','Default production damping0.08, model inertia and mass-distribution assumptions retained.','Allocated duration is not completed integration duration when capsized; early termination is recorded.','High-GM or negative-GM cases test numerical guards and are not a set of100 proven physically feasible craft.'],
  summary,cases:rows,
},null,2)+'\n');
console.log(JSON.stringify(summary));
