# Drag accuracy review — uploaded ZIP only

Production source was read but not changed. The 25 audit cases A056–A080 are in `drag.accuracy.test.ts`; machine-readable observations are in `results/drag.json`. Run `npx vitest run audit/drag.accuracy.test.ts` to reproduce. Six cases deliberately expose unmet accuracy/guard requirements and therefore fail rather than being marked as expected failures.

## What is numerically supported

- Eight independent I1/K1 reference points agree to at worst about **2.65×10⁻⁸ relative error** (0.00000265%). Values were evaluated with 50-digit `mpmath` arithmetic using the defining modified Bessel functions.
- The ITTC-57 coefficient at Re=10⁷ matches its explicit correlation formula. The supplied 205 m worked-example bare friction force is reproduced within **0.00096%**, at the supplied large-ship viscosity and density. This checks one component of that worked example, not total force and not a small model hull.
- A separate, admissible 180 m reference ship checks STAWAVE-2 reflection and motion against independent 50-digit evaluations of the official ITTC equations. Reflection differs by **1.22×10⁻⁸ relative** and motion agrees to floating-point precision.
- Density scaling, the correlation-allowance increment, quadratic wave-height dependence and inviscid Froude/cubic-force scaling behave correctly. These are consistency checks, not measured validation.

## Findings

1. **LCB percentage units error, A070–A071.** `lcbPct` is already a percentage of waterline length. The run-length equation `LR/L = 1 − Cp + 0.06 Cp lcb/(4 Cp − 1)` takes that percentage value directly. `drag.ts` divides it by 100 again. With Cp=.8 and LCB=+5% the computed form factor is 1.296927944 rather than 1.278245674 (**+1.46%**); with LCB=−5% it is 1.297414870 rather than 1.334104700 (**−2.75%**). These are form-factor discrepancies in deliberately chosen analytic cases, not a bound on total drag accuracy.
2. **Silent hull-coefficient substitution, A072.** Cp=.2 produces exactly the same result as Cp=.5 because the function clamps without reporting it. Other inputs are also clamped. An out-of-domain hull should be explicitly flagged or rejected; a finite answer does not validate that hull.
3. **Low-Re friction applicability is undisclosed, A073.** The default 220 mm/.40 m/s setting has Re≈87,649. It receives fully turbulent ITTC-57 Cf≈.0086607 without a per-result applicability flag. A smooth laminar flat-plate assumption would give Cf≈.0044856, illustrating strong model sensitivity; neither coefficient is a measured truth for an arbitrary printed hull. Transition, turbulence trips and surface roughness need assessment or calibration.
4. **Infinite drag at the correlation singularity, A074.** At Re=100, the squared denominator of ITTC-57 vanishes and the function returns infinite Cf and total force. This needs input/domain protection.
5. **Invalid wave period produces a plausible result, A080.** For the reference case, period=0 returns 123,822.68 N rather than rejecting the input. `stawave2` also omits non-finite component terms when forming its total, which can hide other invalid inputs.

## Method applicability and physical accuracy

The official **ITTC 2024** procedure, Appendix G p54, lists STAWAVE-2 calibration restrictions: 50–400 m Lpp, 4<Lpp/B<9, 2.2<B/T<9, .10<Fr<.30, .39<Cb<.90 and waves within ±45° from the bow. The uploaded app deliberately uses Froude-scaled reference conditions. It would be incorrect to reject the inviscid wave formula solely because the model is .22 m long: the non-dimensional equations retain geometric/Froude similitude, as A079 demonstrates. Equivalent full-scale dimensions and the dimensionless hull parameters should be checked. The app currently has no explicit per-hull domain report, and arbitrary STL hulls need not resemble the ship families used for regression.

Froude similitude does **not** preserve Reynolds number in the same fluid. Therefore, a correct STAWAVE-2 arithmetic implementation and a correct large-ship worked example cannot establish the measured total resistance of a 220 mm printed design. No measured tow-tank data for the user's actual designs is present in this ZIP, so no defensible overall drag-error percentage can be assigned from these tests.

## References retrieved for this audit

- [ITTC, Preparation, Conduct and Analysis of Speed/Power Trials, 2024 Revision 08](https://www.ittc.info/media/11972/75-04-01-011.pdf), Appendix G p54, equations G-3 through G-11 and stated restrictions. Downloaded and extracted to the audit workspace on 2026-11-16.
- [Holtrop, A statistical re-analysis of resistance and propulsion data, 1984](https://moodle2.units.it/pluginfile.php/493106/mod_resource/content/0/Holtropsmethod%2088.pdf), p272, form-factor and run-length expressions. Downloaded scanned paper; percentage definition cross-checked against published formula reproductions.
- [NIST DLMF §10.25](https://dlmf.nist.gov/10.25), defining modified Bessel functions; audit constants evaluated with 50-digit mpmath arithmetic.

The reports paraphrase these sources; no physical test measurements were invented.
