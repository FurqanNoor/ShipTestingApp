import { afterAll, describe, expect, it } from 'vitest';
import { besselI1, besselK1, holtrop, stawave2, type HullForm } from '../src/engine/drag';
import { G, NU, RHO, defaultConditions } from '../src/engine/conditions';
import { benchmark, check, finish } from './harness';

const category = 'Drag and method applicability';
const ITTC = 'https://www.ittc.info/media/11972/75-04-01-011.pdf (2024), Appendix G, p54, equations G-3 through G-11';
const HOLTROP = 'Holtrop (1984), A statistical re-analysis of resistance and propulsion data, p272; https://moodle2.units.it/pluginfile.php/493106/mod_resource/content/0/Holtropsmethod%2088.pdf';
const DLMF = 'NIST DLMF modified Bessel definitions, https://dlmf.nist.gov/10.25; 50-digit mpmath evaluation of I_1/K_1, rounded to binary64';
const paperHull: HullForm = { LWL:205, BWL:32, T:10, V:37500, S:7381.45, Cb:37500/(205*32*10), Cm:.98, Cp:.5833, Cwp:.75, lcbPct:-.75, iE:12.08, At:16 };
const refHull: HullForm = { LWL:180, BWL:28, T:8, V:.65*180*28*8, S:5800, Cb:.65, Cm:.98, Cp:.65/.98, Cwp:.8, lcbPct:0, iE:18, At:4 };
const rho=1025, nu=1.1883e-6, U=.25*Math.sqrt(G*180);
const scaleForm = (f:HullForm,s:number):HullForm => ({...f,LWL:f.LWL*s,BWL:f.BWL*s,T:f.T*s,V:f.V*s**3,S:f.S*s**2,At:f.At*s**2});

// Independent published run-length expression: lcb is a PERCENTAGE of LWL, not a fraction.
function referenceFormFactor(f:HullForm) {
  const lr=f.LWL*(1-f.Cp+.06*f.Cp*f.lcbPct/(4*f.Cp-1));
  return .93+.487118*(f.BWL/f.LWL)**1.06806*(f.T/f.LWL)**.46106*(f.LWL/lr)**.121563*(f.LWL**3/f.V)**.36486*(1-f.Cp)**-.604247;
}

afterAll(()=>finish('drag'));

describe('Independent special-function reference values',()=> {
  const points:[string,'I1'|'K1',number,number][]=[
    ['A056','I1',.1,.050062526047092694],
    ['A057','I1',1,.565159103992485],
    ['A058','I1',3.75,7.780015229824416],
    ['A059','I1',10,2670.9883037012546],
    ['A060','K1',.1,9.853844780870606],
    ['A061','K1',1,.6019072301972346],
    ['A062','K1',2,.13986588181652243],
    ['A063','K1',10,.000018648773453825585],
  ];
  it.each(points)('%s: %s(%s) agrees with independent high-precision value',(id,fn,x,expected)=> {
    expect(benchmark({id,category,name:`${fn}(${x}) independent numerical reference`,expected,actual:fn==='I1'?besselI1(x):besselK1(x),relTolerance:2e-7,unit:'dimensionless',severity:'info',note:'Tests arithmetic approximation accuracy only; this does not validate a resistance model.',source:DLMF,kind:'independent numerical reference'})).toBe(true);
  });
});

describe('Holtrop implementation and applicability',()=> {
  it('A064: ITTC-1957 coefficient at prescribed Reynolds number',()=> {
    const reynolds=1e7;
    const r=holtrop(refHull,reynolds*nu/refHull.LWL,rho,nu,G);
    expect(benchmark({id:'A064',category,name:'ITTC-1957 correlation coefficient at Re=10^7',expected:.003,actual:r.Cf,absTolerance:1e-14,unit:'dimensionless',severity:'info',note:'0.075/(7−2)^2. Verifies formula implementation, not measured hull friction.',source:'ITTC-1957 model–ship correlation line'})).toBe(true);
  });
  it('A065: published large-ship example bare skin friction',()=> {
    const r=holtrop(paperHull,25*.514444,rho,nu,G);
    expect(benchmark({id:'A065',category,name:'Worked 205 m ship: skin friction excluding form factor',expected:869630,actual:r.friction/r.formFactor,relTolerance:.01,unit:'N',severity:'info',note:'Only the published 1982 worked-example friction component is compared. This is not total resistance or a 220 mm validation. Expected value also appears in supplied baseline test.',source:'Holtrop & Mennen worked example reproduced in uploaded tests/engine.test.ts'})).toBe(true);
  });
  it('A066: resistance varies linearly with water density',()=> {
    const a=holtrop(refHull,U,998,nu,G),b=holtrop(refHull,U,1025,nu,G);
    expect(benchmark({id:'A066',category,name:'Holtrop density dimensional consistency',expected:1025/998,actual:b.total/a.total,relTolerance:1e-12,unit:'force ratio',severity:'info',kind:'dimensional invariant',note:'All component forces must be proportional to density when other inputs are held fixed.'})).toBe(true);
  });
  it('A067: wave-making term respects cubic force Froude scaling',()=> {
    const s=.01,a=holtrop(refHull,U,rho,nu,G),b=holtrop(scaleForm(refHull,s),U*Math.sqrt(s),rho,nu,G);
    expect(benchmark({id:'A067',category,name:'Holtrop inviscid wave resistance Froude scaling',expected:s**3,actual:b.wave/a.wave,relTolerance:1e-10,unit:'force ratio',severity:'info',kind:'dimensional invariant',note:'Geometric similitude preserves Fn and inviscid force scaling. Total viscous resistance must not be assumed to scale this way at unchanged viscosity.'})).toBe(true);
  });
  it('A068: immersed transom force matches the published coefficient',()=> {
    const speed=1,f={...refHull,At:10};
    const fnt=speed/Math.sqrt(2*G*f.At/(f.BWL*(1+f.Cwp)));
    const expected=.5*rho*speed**2*f.At*.2*(1-.2*fnt);
    expect(benchmark({id:'A068',category,name:'Immersed transom pressure force',expected,actual:holtrop(f,speed,rho,nu,G).transom,relTolerance:1e-12,unit:'N',severity:'info',source:HOLTROP,note:'Compares the explicit c6 transom equation for FnT<5; not a measured transom-flow result.'})).toBe(true);
  });
  it('A069: correlation allowance adds qSCa force',()=> {
    const a=holtrop(refHull,U,rho,nu,G,0),b=holtrop(refHull,U,rho,nu,G,.001);
    expect(benchmark({id:'A069',category,name:'Correlation allowance force increment',expected:.5*rho*U**2*refHull.S*.001,actual:b.total-a.total,relTolerance:1e-12,unit:'N',severity:'info',kind:'dimensional invariant'})).toBe(true);
  });
  it('A070: positive LCB percentage is used without an extra /100',()=> {
    const f={...refHull,Cp:.8,lcbPct:5};
    expect(benchmark({id:'A070',category,name:'Holtrop form factor with LCB=+5% LWL',expected:referenceFormFactor(f),actual:holtrop(f,U,rho,nu,G).formFactor,relTolerance:1e-10,unit:'dimensionless',severity:'medium',source:HOLTROP,note:'The published run-length equation uses lcb as its percentage value. drag.ts divides this percentage by 100, suppressing the longitudinal-CB contribution.'})).toBe(true);
  });
  it('A071: negative LCB percentage is used without an extra /100',()=> {
    const f={...refHull,Cp:.8,lcbPct:-5};
    expect(benchmark({id:'A071',category,name:'Holtrop form factor with LCB=−5% LWL',expected:referenceFormFactor(f),actual:holtrop(f,U,rho,nu,G).formFactor,relTolerance:1e-10,unit:'dimensionless',severity:'medium',source:HOLTROP,note:'Independent equation check with opposite longitudinal-CB sign; isolates the same units error rather than claiming measured ship resistance.'})).toBe(true);
  });
  it('A072: out-of-range prismatic coefficient is not silently substituted',()=> {
    let rejected=false,flagged=false,same=false;
    try {
      const a=holtrop({...refHull,Cp:.2},U,rho,nu,G) as unknown as Record<string,unknown>;
      const b=holtrop({...refHull,Cp:.5},U,rho,nu,G);
      flagged=Boolean(a.warnings||a.valid===false||a.outsideRange===true);
      same=a.total===b.total;
    }catch{rejected=true;}
    expect(check({id:'A072',category,name:'Invalid Cp is rejected or explicitly flagged',expected:'rejection or explicit applicability flag',actual:rejected?'rejected':flagged?'flagged':same?'Cp=0.2 silently produces Cp=0.5 result':'accepted without flag',passed:rejected||flagged,severity:'high',kind:'applicability / guard',note:'The function clamps Cp into [0.5,0.92] without disclosing substitution. A successful finite result is not evidence the input hull lies inside a regression domain.'})).toBe(true);
  });
  it('A073: low model Reynolds number is disclosed as an applicability limit',()=> {
    const cond=defaultConditions(),f=scaleForm(refHull,.22/refHull.LWL);
    let rejected=false,flagged=false,re=NaN,cf=NaN;
    try {
      const r=holtrop(f,cond.speed,RHO,NU,G) as ReturnType<typeof holtrop>&{warnings?:unknown;valid?:boolean;outsideRange?:boolean};
      re=r.Re;cf=r.Cf;flagged=Boolean(r.warnings||r.valid===false||r.outsideRange===true);
    }catch{rejected=true;}
    expect(check({id:'A073',category,name:'Model-scale turbulent-friction applicability disclosure',expected:'low-Re warning / rejected unvalidated turbulent estimate',actual:rejected?'rejected':`Re=${re.toFixed(1)}, Cf=${cf.toFixed(7)}, no applicability flag`,passed:rejected||flagged,severity:'high',kind:'applicability / guard',note:'At ~220 mm/.40 m/s Re≈8.76×10^4. A fully turbulent ITTC-57 correlation is not established for an untripped miniature hull. This test requires disclosure, not substitution of a flat-plate laminar coefficient as measured truth.'})).toBe(true);
  });
  it('A074: the Reynolds-number singularity cannot produce an infinite force',()=> {
    const f={...refHull,LWL:.1};
    let guarded=false,actual='';
    try{const r=holtrop(f,.001,rho,1e-6,G);guarded=Number.isFinite(r.total)&&Number.isFinite(r.Cf);actual=`Re=${r.Re}, Cf=${r.Cf}, total=${r.total}`;}catch{guarded=true;actual='rejected';}
    expect(check({id:'A074',category,name:'Re=100 ITTC-57 singularity guard',expected:'finite result or explicit rejection',actual,passed:guarded,severity:'high',kind:'robustness / guard',note:'0.075/(log10(Re)−2)^2 is singular at Re=100. The function must not return Infinity as a usable drag force.'})).toBe(true);
  });
  it('A075: calm zero-speed resistance is zero',()=> {
    expect(benchmark({id:'A075',category,name:'Zero-speed calm-water resistance',expected:0,actual:holtrop(refHull,0,rho,nu,G).total,absTolerance:0,unit:'N',severity:'info',kind:'physical limiting case'})).toBe(true);
  });
});

describe('STAWAVE-2 independent equations and scaling',()=> {
  it('A076: reflection component matches high-precision ITTC equation evaluation',()=> {
    expect(benchmark({id:'A076',category,name:'STAWAVE-2 reflection component independent reference',expected:80005.14083340176,actual:stawave2(refHull,U,2,8,rho,G).reflection,relTolerance:5e-7,unit:'N',severity:'medium',source:ITTC,kind:'independent numerical reference',note:'Reference uses 50-digit mpmath Bessel values and equations G-9/G-10/G-11 at L=180m,B=28m,T=8m,Cb=.65,Fr=.25,H=2m,Tp=8s; tolerance permits the app’s documented polynomial Bessel approximation.'})).toBe(true);
  });
  it('A077: motion component matches high-precision ITTC equation evaluation',()=> {
    expect(benchmark({id:'A077',category,name:'STAWAVE-2 motion component independent reference',expected:57668.53701788789,actual:stawave2(refHull,U,2,8,rho,G).motion,relTolerance:1e-12,unit:'N',severity:'medium',source:ITTC,kind:'independent numerical reference',note:'Independent 50-digit equation evaluation of G-3 through G-8 using the same admissible large-ship reference and non-dimensional pitch radius kyy=.25. This validates arithmetic, not a physical wave tank.'})).toBe(true);
  });
  it('A078: linear-wave added resistance is quadratic in wave height',()=> {
    const a=stawave2(refHull,U,1,8,rho,G),b=stawave2(refHull,U,2,8,rho,G);
    expect(benchmark({id:'A078',category,name:'STAWAVE-2 wave-height square law',expected:4,actual:b.total/a.total,relTolerance:1e-12,unit:'force ratio',severity:'info',kind:'physical scaling invariant',source:ITTC,note:'All parameters except crest-to-trough wave height fixed. Linear transfer-function theory predicts resistance proportional to amplitude squared.'})).toBe(true);
  });
  it('A079: STAWAVE-2 respects geometric/Froude cubic force scaling',()=> {
    const s=.001,a=stawave2(refHull,U,2,8,rho,G),b=stawave2(scaleForm(refHull,s),U*Math.sqrt(s),2*s,8*Math.sqrt(s),rho,G);
    expect(benchmark({id:'A079',category,name:'STAWAVE-2 Froude similitude',expected:s**3,actual:b.total/a.total,relTolerance:1e-10,unit:'force ratio',severity:'info',kind:'dimensional invariant',source:ITTC,note:'Demonstrates non-dimensional geometric/Froude consistency. It does not establish Reynolds similarity, viscous roll damping, or experimental validation at the miniature scale.'})).toBe(true);
  });
  it('A080: invalid wave period is rejected instead of becoming a plausible force',()=> {
    let rejected=false,actual='';
    try{const r=stawave2(refHull,U,2,0,rho,G);actual=`period=0; total=${r.total}, motion=${r.motion}, reflection=${r.reflection}`;}catch{rejected=true;actual='rejected';}
    expect(check({id:'A080',category,name:'Invalid STAWAVE-2 period guard',expected:'explicit rejection of period=0',actual,passed:rejected,severity:'high',kind:'robustness / guard',note:'A zero period is not a physical wave input. It currently returns a finite reflection force without an error; other non-finite intermediate terms are silently omitted from the total.'})).toBe(true);
  });
});
