# Wave response and placement audit

Scope: only the uploaded `hull-test-bench-source.zip`. No earlier app, engine or methods were imported. Production files were left unchanged. Tests A081–A100 are in `audit/simulation.accuracy.test.ts`; measurements are in `audit/results/simulation.json`.

## What the tests establish

Twelve of these twenty acceptance checks pass. The component spectrum has the correct prescribed variance `m0 = Hs²/16`, satisfies deep-water dispersion `ω² = gk`, and uses a reproducible phase realization. Wave-ramp and head-wave encounter calculations agree with independent cosine equations to round-off. Those are useful implementation checks; they do not validate the hull response model against a wave tank.

For a 200 × 60 × 40 mm box at 240 g and KG = 15 mm, the calculated calm-water buoyancy midpoint is **2.354400006 N**, compared with the independent weight **2.3544 N**. The seeded 0.5° roll disturbance decays to a post-startup maximum of **0.0384°**. For one benign 4 mm/0.45 s beam-wave case, reducing the integration time step by a factor of four changes maximum roll from **5.53653° to 5.50773°**, a **0.52%** difference. This is evidence of numerical convergence for this case, not a general physical accuracy bound.

The time-step comparison changes only the heave-period diagnostic used to select the step; physical mass/inertia, wave components, force law, roll damping and integration duration are unchanged. This avoids claiming convergence based on changing the underlying vessel model.

## Material placement issues

1. **Size eligibility is not enforced by the leaderboard (A095).** `rankModels` does not read `withinLimit`. A synthetic oversized candidate with better category predictions wins with 100 points even though the app's limit is 220 × 220 mm. The UI displays size information separately, so this is a missing ranking/disqualification rule, not a claim that dimensions are hidden.
2. **The documented wave-capsize penalty is not applied (A097).** A load is counted in `validFrac` whenever it floats and has positive upright static stability, even when a wave test capsizes. A sole candidate with one of three load cases capsizing still receives 100 points in every category, rather than the advertised two-thirds factor. Capsize is represented as 90° in the roll average and in a failure counter; the failure counter does not affect the rank calculation. The static sinking penalty does work (A096).
3. **A nonfinite prediction can contaminate every candidate (A100).** A single otherwise statically valid candidate with `NaN` drag makes `bestDrag` and all drag/total scores `NaN`. A zero-drag field also produces `0/0` and `NaN` scores (A098). Zero speed is physically meaningful, although the current UI imposes a 0.01 m/s minimum.
4. **Scores depend on the competing field (A099).** An A/B example changes from B ahead by 10 points to A ahead by 15.33 points when a third candidate is added. This follows the stated normalization formula and is **not an implementation bug**. It does mean these totals are not intrinsic hull-quality scores, and placements may change when the field changes. Competition criteria should be fixed before testing.

## Numerical and applicability safeguards

- `simulate` silently limits integration to 30,000 steps. A requested 450 s public-API run completes only 225 s (A090). The default app uses 40 peak periods and was not truncated in the benign convergence case above; this failure must not be represented as evidence that every default run is shortened.
- A deliberately out-of-domain 1,000 m/s input reaches the step cap before the five-period measurement window starts. It nevertheless returns plausible force extrema equal to `mg` because empty statistics are replaced with weight (A092). Such an extreme speed is physically inappropriate, but the UI has no upper speed bound. The appropriate repair is domain rejection or unavailable statistics with a reason, rather than returning an apparently measured force.
- `makeSetup` clamps negative/small transverse restoring stiffness for damping and time-step selection. A negative-GM input therefore produces a finite positive internal natural-period diagnostic (1.32035 s in A089). The main result separately flags negative GM and withholds its user-facing roll period; this is an internal applicability/diagnostic issue and should not be described as the UI declaring an unstable hull stable.

## Physical validation still missing

The simulator integrates a selected buoyancy/force law over rasterized columns and assumes added mass, damping and inertia. Roll inertia is `mass × (0.38 × beam)²`; the app does not obtain actual mass distribution or inertia from the STL. Auto CG is the centre of the reconstructed envelope volume, not the measured centre of mass of a hollow print, ballast and cargo. These choices can move resonance and roll amplitude substantially.

The local wave-normal/pressure-decay force treatment is a reduced-order approximation. It is not a solved viscous free-surface flow, radiation/diffraction solution, flooding model or calibrated response operator. The irregular sea consists of 20 deterministic components and the default response maximum is sampled over roughly 35 peak periods after startup. A maximum over that single short realization is not a probabilistic extreme roll rating.

No uploaded hull-specific mass/CG/inertia measurements, tow-tank force data or wave-tank motions accompany this ZIP. Consequently the audit cannot defend a percentage accuracy for drag, roll, pitch, heave or capsize prediction. For placements, first fix eligibility and scoring rules, then validate repeatable predictions against measured designs at the intended size, speed, load and wave conditions.

The **12/20 pass count is not “60% physical accuracy.”** It mixes algebra, numerical convergence, domain guards and scoring-policy acceptance checks. Each failed criterion states whether it is an implementation defect, an unsupported input, or a deliberate scoring-design sensitivity.

## Additional 100 production-resolution simulations

`audit/stress-simulations.ts` runs the actual uploaded `simulate` function at the application's dynamic grid resolution, `gridSize(L, B, 110, 5000)`, without editing it. Results are in `audit/results/stress-simulations.json`.

The matrix is **five geometries × five capacity fractions × four water conditions = 100 runs**. Geometries are three boxes (ordinary, wide and tall/narrow) plus two ferry-proportion examples. Fractions are 5%, 15%, 30%, 50% and 70% of the rasterized upright rim capacity. Each runs calm water and all three default wave presets, in beam seas for 40 peak periods, with KG at 50% of model depth and the default damping. These are 100 additional stress simulations, separate from the 100 acceptance tests shared across the whole audit.

| Numerical/reliability observation | Result |
| --- | --- |
| Runs completed | 100 |
| Finite stored motion traces | 100/100 |
| Finite reported scalar statistics | 100/100 |
| Buoyancy within 0–fully immersed displacement force | 100/100 |
| Maximum upright relative force-balance residual | 3.49 × 10⁻¹⁰ |
| Runs hitting the 30,000-step duration cap | 0 |
| Initially negative-GM cases | 20 |
| Simulated capsizes | 20 |
| Capsizes before the post-startup measurement window | 20 |
| Wet-deck reports | 32, including 12 initially stable cases |
| Total runtime on this machine | 8.98 s |

The twenty unstable runs detect capsize early and fill the remaining motion arrays with their final pose. Their finite force statistics use the existing `mg` fallback when the measurement window has not started. They must not be interpreted as measured, complete 40-period force histories. The twelve initially stable wet-deck cases show why a dry-interior/open-hull model needs a flooding or explicit applicability limit: this simulator tracks deck clearance but does not calculate water ingress.

The 80 initially stable cases did not numerically capsize in this matrix. That is a code observation, **not** evidence that the real hulls cannot capsize. No head-wave drag validation, measured motion data or physical force reference was introduced by this stress matrix.

Reproduce from the uploaded project directory:

```sh
npx esbuild audit/stress-simulations.ts --bundle --platform=node --format=esm --outfile=audit/stress-run.mjs
node audit/stress-run.mjs
```
