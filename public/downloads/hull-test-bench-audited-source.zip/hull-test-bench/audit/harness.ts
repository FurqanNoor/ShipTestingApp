import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

export type Severity = 'info'|'medium'|'high'|'critical';
export interface AuditRow {
  id:string;
  category:string;
  name:string;
  expected:number|string|boolean|null;
  actual:number|string|boolean|null;
  unit:string;
  absoluteError:number|null;
  relativeError:number|null;
  allowedError:number|null;
  passed:boolean;
  note:string;
  severity:Severity;
  kind:string;
  source:string;
}
const rows:AuditRow[]=[];
const safeNumber=(n:number):number|string=>Number.isFinite(n)?n:String(n);
function record(row:AuditRow) {
  if(rows.some(r=>r.id===row.id))throw new Error(`Duplicate audit ID ${row.id}`);
  rows.push(row);
}

export function benchmark(s:{id:string;category:string;name:string;expected:number;actual:number;absTolerance?:number;relTolerance?:number;unit:string;note?:string;severity?:Severity;kind?:string;source?:string}):boolean {
  const valid=Number.isFinite(s.expected)&&Number.isFinite(s.actual);
  const allowedError=Math.max(s.absTolerance??0,(s.relTolerance??0)*Math.abs(s.expected));
  const absoluteError=valid?Math.abs(s.actual-s.expected):null;
  const passed=valid&&absoluteError!<=allowedError;
  record({id:s.id,category:s.category,name:s.name,expected:safeNumber(s.expected),actual:safeNumber(s.actual),unit:s.unit,absoluteError,relativeError:valid&&s.expected!==0?absoluteError!/Math.abs(s.expected):null,allowedError,passed,note:s.note??'',severity:s.severity??'medium',kind:s.kind??'analytical benchmark',source:s.source??''});
  return passed;
}

export function check(s:{id:string;category:string;name:string;passed:boolean;expected:string|number|boolean|null;actual:string|number|boolean|null;note?:string;severity?:Severity;kind?:string;source?:string}):boolean {
  record({id:s.id,category:s.category,name:s.name,expected:typeof s.expected==='number'?safeNumber(s.expected):s.expected,actual:typeof s.actual==='number'?safeNumber(s.actual):s.actual,unit:'',absoluteError:null,relativeError:null,allowedError:null,passed:s.passed,note:s.note??'',severity:s.severity??'medium',kind:s.kind??'behaviour / applicability check',source:s.source??''});
  return s.passed;
}

export function finish(stem:string) {
  const dir=resolve('audit/results');mkdirSync(dir,{recursive:true});
  writeFileSync(resolve(dir,stem+'.json'),JSON.stringify({source:'Uploaded hull-test-bench-source.zip only; production source unchanged',cases:rows.sort((a,b)=>a.id.localeCompare(b.id))},null,2)+'\n');
}
