import { afterAll, describe, expect, it } from 'vitest';
import { buildColumns, solveLevel, submerged } from '../src/engine/hull';
import { floatUpright, gzCurve, maxLoadVolume } from '../src/engine/hydrostatics';
import { benchmark, finish } from './harness';

type P = [number, number];

/** Independent convex-prism fixture, dimensions in metres. No app geometry generator. */
function prism(length: number, polygon: P[]): Float32Array {
  const out: number[] = [];
  const point = (x: number, p: P) => [x, p[0], p[1]];
  const tri = (a: number[], b: number[], c: number[]) => out.push(...a, ...b, ...c);
  for (const x of [0, length])
    for (let j = 1; j < polygon.length - 1; j++) tri(point(x, polygon[0]), point(x, polygon[j]), point(x, polygon[j + 1]));
  for (let j = 0; j < polygon.length; j++) {
    const a = polygon[j], b = polygon[(j + 1) % polygon.length];
    tri(point(0, a), point(length, a), point(length, b));
    tri(point(0, a), point(length, b), point(0, b));
  }
  return new Float32Array(out);
}

/** Independent exact polygon/half-plane reference, not the app's column algorithm. */
function clip(poly: P[], ny: number, nz: number, level: number): P[] {
  const result: P[] = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const va = ny * a[0] + nz * a[1] - level, vb = ny * b[0] + nz * b[1] - level;
    if (va <= 0) result.push(a);
    if ((va <= 0) !== (vb <= 0)) {
      const f = va / (va - vb);
      result.push([a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1])]);
    }
  }
  return result;
}
function centroid(poly: P[]) {
  let a = 0, y = 0, z = 0;
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length];
    const cross = p[0] * q[1] - q[0] * p[1];
    a += cross; y += (p[0] + q[0]) * cross; z += (p[1] + q[1]) * cross;
  }
  return Math.abs(a) < 1e-30 ? { area: 0, y: 0, z: 0 } : { area: Math.abs(a / 2), y: y / (3 * a), z: z / (3 * a) };
}
function reference(poly: P[], area: number, degrees: number, kg: number) {
  const rad = degrees * Math.PI / 180, ny = Math.sin(rad), nz = Math.cos(rad);
  let lo = Math.min(...poly.map(p => ny * p[0] + nz * p[1]));
  let hi = Math.max(...poly.map(p => ny * p[0] + nz * p[1]));
  for (let k = 0; k < 90; k++) {
    const mid = (lo + hi) / 2;
    if (centroid(clip(poly, ny, nz, mid)).area < area) lo = mid; else hi = mid;
  }
  const c = centroid(clip(poly, ny, nz, (lo + hi) / 2));
  return { ...c, level: (lo + hi) / 2, gz: (c.z - kg) * ny - c.y * nz };
}

const L = 0.2, B = 0.06, D = 0.04, T = 0.02, KG = 0.02;
const boxPoly: P[] = [[-B / 2, 0], [B / 2, 0], [B / 2, D], [-B / 2, D]];
const box = buildColumns(prism(L, boxPoly), 0.001);
const V = L * B * T;
const up = floatUpright(box, V)!;
const boxGz = gzCurve(box, V, 0, KG);
const getGz = (curve: ReturnType<typeof gzCurve>, d: number) => curve.gz[curve.deg.indexOf(d)];
const halfFillGM = T / 2 + B * B / (12 * T) - KG;
const shallow = floatUpright(box, L * B * 0.002)!;
const veryShallow = floatUpright(box, L * B * 0.0002)!;
const nonAlignedV = L * B * 0.0137;
const sideways = solveLevel(box, 0, 1, 0, nonAlignedV)!;

const wedgePoly: P[] = [[-B / 2, D], [0, 0], [B / 2, D]];
const wedge = buildColumns(prism(L, wedgePoly), 0.001);
const wedgeT = 0.02;
const wedgeV = L * B * wedgeT * wedgeT / (2 * D);
const wedgeUp = floatUpright(wedge, wedgeV)!;
const wedgeGz = gzCurve(wedge, wedgeV, 0, 0.015);
const wedgeWidth = B * wedgeT / D;

interface Case { id: string; name: string; actual: number; expected: number; absTolerance: number; relTolerance: number; unit: string; note?: string; severity?: 'info' | 'medium' | 'high' | 'critical' }
const cases: Case[] = [
  {id:'A001',name:'Aligned rectangular prism: enclosed volume',actual:box.volume,expected:L*B*D,absTolerance:1e-12,relTolerance:1e-6,unit:'m³'},
  {id:'A002',name:'Aligned box: equilibrium draft by Archimedes',actual:up.T,expected:T,absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A003',name:'Aligned box: vertical centre of buoyancy',actual:up.zB,expected:T/2,absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A004',name:'Aligned box: longitudinal centre of buoyancy',actual:up.xB,expected:L/2,absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A005',name:'Aligned box: waterplane area',actual:up.Awp,expected:L*B,absTolerance:1e-10,relTolerance:1e-6,unit:'m²'},
  {id:'A006',name:'Aligned box: transverse waterplane second moment',actual:up.IT,expected:L*B**3/12,absTolerance:1e-12,relTolerance:1e-6,unit:'m⁴'},
  {id:'A007',name:'Aligned box: longitudinal waterplane second moment',actual:up.IL,expected:B*L**3/12,absTolerance:1e-12,relTolerance:1e-6,unit:'m⁴'},
  {id:'A008',name:'Aligned box: transverse metacentric radius',actual:up.BMt,expected:B*B/(12*T),absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A009',name:'Aligned box: initial GM for measured KG',actual:up.zB+up.BMt-KG,expected:halfFillGM,absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A010',name:'Aligned box: exact wetted area at 20 mm draft',actual:up.S,expected:L*B+2*T*(L+B),absTolerance:0,relTolerance:0.02,unit:'m²',note:'2% screening tolerance for 1 mm grid surface-area estimate.'},
  {id:'A011',name:'Aligned box: freeboard',actual:up.freeboard,expected:D-T,absTolerance:1e-9,relTolerance:1e-6,unit:'m'},
  {id:'A012',name:'Aligned box: maximum upright displacement',actual:maxLoadVolume(box),expected:L*B*D,absTolerance:1e-12,relTolerance:1e-6,unit:'m³'},
  {id:'A013',name:'Shallow box: wetted area at 2 mm draft',actual:shallow.S,expected:L*B+2*.002*(L+B),absTolerance:0,relTolerance:.02,unit:'m²',note:'2 mm draft is representative of ~24 g on this box; same 2% area target.'},
  {id:'A014',name:'Very shallow box: wetted area at 0.2 mm draft',actual:veryShallow.S,expected:L*B+2*.0002*(L+B),absTolerance:0,relTolerance:.02,unit:'m²',note:'Sub-cell draft stress case; same 2% wetted-area target.'},
  ...[5,15,30,60,85,90].map((d,i):Case=>({id:`A${String(15+i).padStart(3,'0')}`,name:`Sealed box: GZ at ${d}° versus exact polygon`,actual:getGz(boxGz,d),expected:reference(boxPoly,V/L,d,KG).gz,absTolerance:2e-5,relTolerance:.01,unit:'m',note:'Numerical sealed-solid reference, including deck immersion; does not validate open-boat flooding.',severity:d>=60?'high':'medium'})),
  {id:'A021',name:'Box at exactly 90°: target displacement is conserved',actual:sideways.V,expected:nonAlignedV,absTolerance:0,relTolerance:.01,unit:'m³',note:'Target corresponds to 13.7 mm upright draft; continuous physical immersion must conserve it. 1% volume tolerance.',severity:'high'},
  {id:'A022',name:'Box: first deck-edge immersion angle',actual:boxGz.deckEdgeDeg,expected:Math.atan((D-T)/(B/2))*180/Math.PI,absTolerance:.25,relTolerance:0,unit:'degrees',note:'0.25° tolerance for linearly interpolated 2.5° GZ sweep.'},
  {id:'A023',name:'V-section prism: closed volume',actual:wedge.volume,expected:L*B*D/2,absTolerance:0,relTolerance:.01,unit:'m³',note:'1% discretization tolerance at 1 mm grid.'},
  {id:'A024',name:'V-section prism: analytical draft',actual:wedgeUp.T,expected:wedgeT,absTolerance:1e-4,relTolerance:0,unit:'m',note:'0.1 mm draft tolerance.'},
  {id:'A025',name:'V-section prism: centre of buoyancy KB = 2T/3',actual:wedgeUp.zB,expected:2*wedgeT/3,absTolerance:1e-4,relTolerance:0,unit:'m',note:'0.1 mm centroid tolerance.'},
  {id:'A026',name:'V-section prism: analytical waterplane area',actual:wedgeUp.Awp,expected:L*wedgeWidth,absTolerance:0,relTolerance:.02,unit:'m²',note:'2% waterplane tolerance on a 1 mm raster.'},
  {id:'A027',name:'V-section prism: transverse waterplane inertia',actual:wedgeUp.IT,expected:L*wedgeWidth**3/12,absTolerance:0,relTolerance:.03,unit:'m⁴',note:'3% inertia tolerance; width error enters cubically.'},
  {id:'A028',name:'V-section prism: analytical initial GM',actual:wedgeUp.zB+wedgeUp.BMt-.015,expected:2*wedgeT/3+(L*wedgeWidth**3/12)/wedgeV-.015,absTolerance:1e-4,relTolerance:.03,unit:'m',note:'0.1 mm or 3% tolerance for derived static GM.'},
  {id:'A029',name:'Sealed V-section prism: GZ at 10°',actual:getGz(wedgeGz,10),expected:reference(wedgePoly,wedgeV/L,10,.015).gz,absTolerance:5e-5,relTolerance:.03,unit:'m',note:'0.05 mm or 3% GZ tolerance against independent exact polygon clipping.'},
  {id:'A030',name:'Sealed V-section prism: GZ at 45°',actual:getGz(wedgeGz,45),expected:reference(wedgePoly,wedgeV/L,45,.015).gz,absTolerance:5e-5,relTolerance:.03,unit:'m',note:'Sealed-solid numerical reference; no flooding claim.'},
];

describe('Uploaded-source hydrostatics accuracy audit — 30 independent benchmarks',()=>{
  for(const c of cases)it(`${c.id} ${c.name}`,()=>{
    const passed=benchmark({...c,category:'Hydrostatics and static stability'});
    expect(passed,`${c.id}: actual=${c.actual}; expected=${c.expected}; ${c.note??''}`).toBe(true);
  });
  afterAll(()=>finish('hydro'));
});
