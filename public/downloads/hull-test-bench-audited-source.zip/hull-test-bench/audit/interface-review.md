# Interface, export and scientific-claim review

Scope: only the supplied `hull-test-bench-source.zip`. This is a read-only source review; no production files were changed, and no earlier application was used. These findings supplement the separate 100-case numerical audit. They are not additional automated test cases. Browser interaction was not performed for this review.

## High-priority findings

### 1. Changing conditions can temporarily rank or export mixed protocols

Evidence:

- `src/ui/main.ts:371–376` mutates the shared `state.cond` object in place.
- `src/ui/main.ts:116–118` then reruns the models sequentially.
- Only the model currently starting a rerun has its previous result cleared (`src/ui/main.ts:61–74`). Later models retain their old results until their turn.
- `ranked()` includes every model with a non-null result (`src/ui/main.ts:223–226`). Excel stays enabled whenever that list is nonempty (`src/ui/main.ts:296`).
- Export passes those result objects with the *current* condition object to a workbook containing just one Test conditions sheet (`src/ui/main.ts:421–424`; `src/report.ts:95–129`). No immutable condition snapshot or protocol identifier is saved with a `ModelResult`.

Reproduction path: finish two models, change the speed or weights, apply and re-test, then export after model A finishes while model B is still waiting for or performing its rerun. Old B results and new A results can appear under the new condition sheet. A busy state exists but does not disable export or globally invalidate all old results. If conditions are edited again during a run, the active analyzer also holds references to the mutable weight/wave arrays.

Impact: the app can violate its central claim that leaderboard designs were tested under identical conditions. Completed, uninterrupted runs after the whole queue finishes avoid this particular race.

### 2. The tank badge does not establish boundary independence

`src/ui/main.ts:240–260` calls `tankChecks(c)` without the actual model length or immersed section. The defaults are a 220 mm length and 0.0004 m² section (`src/engine/conditions.ts:84`). The same call appears in the workbook (`src/report.ts:119–120`). Yet the badge says **“no wall or floor effects”**, and README lines 42–44 say the tank is sized so walls/floor would not change results.

The tank is drawn by `src/ui/view3d.ts:169–184`; the motion and drag calculations do not solve tank walls, reflected waves, absorbing boundaries or finite-depth flow. Changing the tank changes the drawing and heuristic checks, not calculated boundary forces. The checks are useful preliminary rules of thumb, not convergence evidence. They are also based on default geometry rather than the imported hull, and the depth test uses the longest peak-period wavelength rather than verifying every discrete spectrum component.

Impact: the analytical calculations assume open/deep water. They cannot certify that a real tank of the displayed dimensions produces negligible interference.

### 3. The interface overstates the calculated capsize limit

`src/ui/main.ts:202` displays a final GZ endpoint of 90° as **“>90 Capsizes beyond”**. The engine only sweeps through 90° (`src/engine/hydrostatics.ts:123–164`), so it establishes neither a capsize angle beyond 90° nor recovery after inversion. The Excel header is more careful: “90 = none up to 90” (`src/report.ts:38`).

The plot marks the deck-immersion angle, but continues to show GZ beyond it as a normal righting-arm curve (`src/ui/main.ts:148–168`). For an open boat, those later points assume the virtually sealed envelope; no water ingress or moving floodwater is solved. They therefore do not establish the physical roll capability of an open printed hull.

## Other material limitations and inconsistencies

### 4. Calm-water “Dry” can disagree with computed freeboard

The calm row hardcodes `deck: "Dry"` in `src/ui/main.ts:207`; the Excel calm row also writes “Dry” (`src/report.ts:63`). This can disagree with `w.freeboardMm <= 0`, for which the freeboard tile itself is marked bad (`src/ui/main.ts:197`). A varying-height rim can be immersed before the full envelope reaches its total volume. The floating-condition calculation does not itself enforce a dry-rim criterion.

The side-panel verdict also checks all wave presets rather than the selected calm/wave row (`src/ui/main.ts:134–141`). That is a useful worst-condition summary, but it should be identified as such.

### 5. The workbook omits failed wave cases and can call an unstable wave case “OK”

The Summary sheet retains a sinking weight as “Sinks” (`src/report.ts:42–44`), but the Wave tests sheet skips that weight entirely (`src/report.ts:62`). It consequently does not always retain the stated complete 3-weight × 4-water-condition matrix.

Wave-row Result is based only on `v.capsized` (`src/report.ts:67`), whereas the calm Result checks `w.stable` (`src/report.ts:63`). If an initially unstable case has not crossed the simulation's capsize cutoff during the finite run, the wave row can say “OK” while Summary says “Tips over.” A wet deck is shown separately but can likewise coexist with Result “OK.”

### 6. Default CG is a geometry assumption, not measured mass distribution

The default is `cgMode: "auto"` (`src/engine/conditions.ts:74`), evaluated as the centroid of the reconstructed enclosed volume (`src/engine/analyze.ts:79`). This is neither the centroid of a thin printed wall nor a measurement of hull, electronics, ballast, luggage and cargo. One KG is then used for every weight case. The UI does disclose “Centre of the model's volume” (`src/ui/main.ts:251,262`), but users must not treat the automatic setting as inferred physical CG. Real CG differences can dominate roll stability and ranking.

### 7. A table row combines separate heading tests

Selecting Ahead/Side changes the live animation (`src/ui/main.ts:308–309`), while the drag/wave table remains a combined summary. The scalar wave case is assembled from head-wave drag/pitch/heave, the maximum of head/beam roll, the minimum/maximum buoyancy across both runs, and the worst clearance across both runs (`src/engine/analyze.ts:113–124`). These extrema need not occur together, or even in the same heading. They must not be interpreted as one synchronized force/motion observation.

### 8. Edited conditions retain misleading full-scale reference descriptions

After wave heights or test speed are edited, the UI still describes 2/4/6 m full-size seas and 18 knots (`src/ui/main.ts:258–259`). The workbook likewise retains the original full-scale weight basis, wave notes and 18-knot reference alongside arbitrary edited numeric model conditions (`src/report.ts:109,113–114`). These are reasonable descriptions of the defaults, but cease to be the corresponding full-scale equivalents after edits. The model-scale numeric values themselves are exported correctly.

## Positive checks from the source

- The renderer uses the actual placed STL triangles (`src/ui/view3d.ts:86–99`); it does not substitute a generic ship.
- The viewer's `YXZ` rotation order and roll/pitch mapping are consistent with the engine's vertical-normal convention (`src/ui/view3d.ts:68,232–234`; `src/engine/sim.ts:186`).
- N to mN, m to mm, m³ to cm³ and m² to cm² conversions in the reviewed display/export paths are correct (`src/ui/main.ts:217`; `src/engine/analyze.ts:128–135`; `src/report.ts:49,66,89–90`). Number formatting changes display precision rather than stored numeric values.
- Excel writes names and other text as literal `inlineStr` cells, not formulas (`src/xlsx.ts:28–33`). Formula-like filenames are not executed as spreadsheet formulas through this path.
- The standalone-file build bundles JavaScript and CSS, but web fonts still depend on external Google Fonts (`scripts/build.mjs:24–28`; `index.html:7–9`). This does not change numerical results.

## Suggested correction order, without changing this audited version

1. Store immutable per-result conditions and prevent comparison/export until all runs share the same protocol.
2. Replace the boundary-independence claim with an explicit open-water assumption and geometry-specific preliminary checks.
3. Withhold physical capsize claims past the evaluated range or past open-rim immersion.
4. Preserve failed cases in every export matrix, and make status labels consistent with stability and deck-wet flags.
5. Require measured mass distribution for physical roll comparisons; separate the heading-specific results from combined worst-case summaries.
