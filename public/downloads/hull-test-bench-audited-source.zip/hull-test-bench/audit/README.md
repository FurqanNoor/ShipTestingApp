# Hull Test Bench — independent accuracy audit

16 November 2026 · Uploaded ZIP only · Original production files unchanged

**Verdict:** a useful development base, but this version should not determine final team placements. Static buoyancy and small-angle stability work well on the tested ideal closed hulls. Open/thin-wall displacement, scoring safeguards and several interpretation claims need correction. Real drag and wave accuracy remain unvalidated.

## What was run

- All 14 supplied tests passed; the production build passed.
- Exactly 100 new independent acceptance checks: **74 passed, 26 failed**; no skipped or expected-failure cases.
- A further **100 actual beam-wave simulation runs**: five hull forms × five load fractions × calm plus three wave presets, using the app's production dynamic-grid settings and 40 peak periods.
- All 27 original extracted files were SHA-256 checked and remain unchanged. The previous app was neither imported nor integrated.

**74/100 is a software test pass rate, not 74% physical accuracy.** The suite mixes analytical benchmarks, algebraic consistency, input safeguards and ranking-policy criteria. The ledger records each tolerance and actual result. Some failures expose deliberate heuristic limitations or a policy sensitivity, rather than an implementation defect.

| Area | Checks | Passed | Failed |
| --- | ---: | ---: | ---: |
| Hydrostatics / static stability | 30 | 29 | 1 |
| STL / geometry / orientation | 25 | 14 | 11 |
| Drag arithmetic / applicability | 25 | 19 | 6 |
| Waves / numerical safeguards / ranking | 20 | 12 | 8 |

## Main findings

### 1. Open and printed hull displacement can be wrong by most of the actual volume.

**Critical.** A 200 × 60 × 40 mm thin-wall basin should exclude 480 cm³ of water when dry up to its rim. The engine returns 62.912 cm³: exactly the plastic-wall material volume, 86.9% too low. An open flat-bottom exterior skin returns zero instead of 480 cm³. Vertically separated shells are bridged, adding a false 50% displacement in one fixture.

Evidence: `A051–A053; src/engine/hull.ts:32–95`.

### 2. The leaderboard cannot yet support defensible team placements.

**Critical.** An oversized hull can win. A statically stable load that capsizes in waves still counts fully in the advertised one-third-per-failed-load factor. Nonfinite or zero drag can propagate NaN scores. Changing settings while sequential retests run can compare or export old and new conditions together, because results have no immutable protocol snapshot.

Evidence: `A095, A097, A098, A100; src/engine/analyze.ts:195–218; audit/interface-review.md`.

### 3. Drag has a specific coefficient error and unvalidated model-scale assumptions.

**High.** The Holtrop run-length term divides the already-percent LCB by 100 again. Selected reference cases show +1.46% and −2.75% form-factor discrepancies; these are not total-drag error bounds. Default model Re is about 87,649, yet fully turbulent ITTC-57 friction is used without a per-result applicability flag. Clamped coefficients and invalid inputs can still produce plausible output.

Evidence: `A070–A074, A080; src/engine/drag.ts:41–50`.

### 4. Capsize, flooding and boundary statements exceed what is actually calculated.

**High.** Open-rim GZ after deck immersion assumes the virtually sealed hull, without water ingress. A 90° sweep does not establish a capsize angle beyond 90°. The tank checks are preliminary heuristics using default hull dimensions; no wall/reflection/finite-depth flow or domain-convergence study is solved. Calm rows can say Dry despite an immersed rim.

Evidence: `A021; audit/interface-review.md; src/ui/main.ts:197–207,240–260`.

### 5. Real wave-response accuracy remains unmeasured.

**High.** CG defaults to the envelope-volume centroid. Actual wall thickness, ballast, cargo CG, roll inertia, added mass and damping are not measured. One benign time-step check changes predicted roll by 0.52%, but this only tests numerical convergence. A single short, deterministic irregular-wave realization cannot certify extreme roll or capsize probability.

Evidence: `A088–A092; src/engine/sim.ts:99–150; audit/simulation-method-review.md`.

### 6. Automatic geometry assumptions and grid errors need explicit checks.

**Medium.** The tested positive-up axis rotations recover correctly; all 12 inverted-up rotations retain an upside-down keel. A known 20 mm file is guessed as centimetres. At the exact production fine-grid resolution, a 220 × 37 × 16.5 mm box has +2.196% capacity error. An open V prism is 3.33% low. These examples do not bound errors on arbitrary STL files.

Evidence: `A040–A047, A055; src/engine/orient.ts:99–150`.


## Quantified numerical results

- **Aligned closed box:** Draft, KB, waterplane inertia and GM agree closely with analytical values on the aligned grid.
- **Wetted surface, box:** 0.69–1.77% low in the three tested drafts at a 1 mm grid.
- **V-section prism:** KB error 0.056%; initial GM error about 0.127% in the selected case.
- **Box righting arm:** 5–60° GZ errors about 0.065–0.083%; 85° about 0.632%. Near-zero GZ uses absolute error.
- **Exactly 90° heel:** Displacement is 2.19% above the target in A021, failing the preselected 1% tolerance.
- **Bessel / STAWAVE arithmetic:** Selected independent high-precision formula references agree closely; this does not validate actual hull forces.
- **Time-step refinement:** One wave case: 5.53653° → 5.50773° maximum roll with a fourfold smaller time step, a 0.52% change.

These are errors against synthetic analytical shapes or independent equations, at the specified settings. They are not measured accuracy on your own ship designs and cannot be pooled into one accuracy percentage.

## The 100 additional simulations

All 100 runs produced finite arrays/statistics and stayed within the selected displacement-force bound. No 30,000-step duration cap was reached. Static force-balance relative residual was at most 3.50 × 10⁻¹⁰.

However, **20 initially unstable cases capsized before the measurement window**. Their apparently reasonable buoyancy extrema include the engine's `mg` fallback, rather than post-startup wave measurements. There were 32 wet-deck cases in total, including 12 that were initially statically stable. Flooding is not simulated. Finite output alone is therefore not evidence of a physically valid test. The stress matrix uses capacity fractions, not the application's three preset gram values; see the separate per-run sheet.

## What is needed before placements

1. Reconstruct and validate the exterior water-excluding hull volume correctly for your actual STL exports; do not use plastic-material volume as buoyancy.
2. Snapshot conditions with every result, prevent mixed-protocol comparison, enforce size eligibility and agreed failure penalties, and isolate nonfinite values.
3. Fix the LCB percentage calculation and report each drag method's assumptions/domain. Do not infer model drag accuracy from one full-size worked example.
4. Require measured loaded mass and CG; characterize inertia and damping for roll. Stop physical GZ/capsize interpretation at flooding or the evaluated angle limit.
5. Compare predictions with repeatable tow/wave-tank measurements or validated free-surface CFD for representative designs. Quantify error and repeatability relative to the differences between teams before assigning places.

There are no measured force, CG/inertia or wave-motion reference data for your actual designs in the uploaded ZIP. A defensible overall physical-error percentage cannot be obtained from this archive alone.

## Reproduce

Run from the extracted `hull-test-bench` directory:

```sh
npm ci
npm test -- --run tests/engine.test.ts
npm run build
npx vitest run audit/hydro.accuracy.test.ts audit/geometry.accuracy.test.ts audit/drag.accuracy.test.ts audit/simulation.accuracy.test.ts --maxWorkers=4 --minWorkers=1 --reporter=json --outputFile=audit/results/audit-vitest.json
npx esbuild audit/stress-simulations.ts --bundle --platform=node --format=esm --outfile=audit/stress-run.mjs
node audit/stress-run.mjs
```

The 100-case audit command intentionally exits with status 1 because 26 acceptance criteria are unmet. No assertions were weakened or changed to expected failures. The original tests still pass. Audit additions are under `audit/`; the production files are unchanged.

## Sources and provenance

- [ITTC 2024 speed/power trial procedure, Appendix G: STAWAVE-2 equations and restrictions](https://www.ittc.info/media/11972/75-04-01-011.pdf)
- [Holtrop 1984: statistical resistance re-analysis, form-factor / LCB expression](https://moodle2.units.it/pluginfile.php/493106/mod_resource/content/0/Holtropsmethod%2088.pdf)
- [NIST DLMF 10.25: modified Bessel functions](https://dlmf.nist.gov/10.25)

Input: `hull-test-bench-source.zip` (124,803 bytes). SHA-256: `70adb3f12db1040c5706171ac824b9aef780fffbbaec3f28f082064b5bc33e66`.

Files `audit/results/all-100-cases.json`, `audit/results/audit-vitest.json` and `audit/results/stress-simulations.json` retain the complete observations. `audit/original-source-hashes.json` fingerprints all original files. The source-only interface review records line-level evidence for the additional display/export findings. Browser interactions were not tested; this audit does not claim visual or end-to-end browser verification.
