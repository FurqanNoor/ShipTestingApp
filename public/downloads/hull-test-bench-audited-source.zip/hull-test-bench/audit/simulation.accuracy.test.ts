import { afterAll, describe, expect, it } from 'vitest';
import { rankModels, type ModelResult, type WeightResult, type WaveCase } from '../src/engine/analyze';
import { G, RHO } from '../src/engine/conditions';
import { boxHull } from '../src/engine/example';
import { buildColumns } from '../src/engine/hull';
import { floatUpright } from '../src/engine/hydrostatics';
import { elevation, makeSetup, seaComponents, simulate, type SimResult } from '../src/engine/sim';
import { benchmark, check, finish } from './harness';

const category='Wave simulation and ranking';
const cols=buildColumns(boxHull(200,60,40).map(v=>v*.001),.002);
const mass=.24,kg=.015,up=floatUpright(cols,mass/RHO)!;
const gm=up.zB+up.BMt-kg;
const hydro={Awp:up.Awp,xF:up.xF,IL:up.IL,GM:gm,stationBeam:up.stationBeam};
const setup=makeSetup(cols,mass,kg,RHO,G,hydro,.08)!;
let calm:SimResult|undefined,wave:SimResult|undefined;
const calmRun=()=>calm??=(simulate(setup,0,.45,true,0));
const waveRun=()=>wave??=(simulate(setup,.004,.45,true,0,20));

/** Deliberately simple score records isolate ranking algebra from unvalidated fluid models. */
function model(dragN:number,rollDeg:number,loadG:number, options:{withinLimit?:boolean;sinks?:number;capsizes?:number}={}):ModelResult {
  const weights=Array.from({length:3},(_,i)=>({
    floats:i>=(options.sinks??0),stable:i>=(options.sinks??0),
    calm:{total:dragN},waves:Array.from({length:3},()=>({dragN,maxRollDeg:rollDeg,capsized:i<(options.capsizes??0)} as WaveCase)),
  } as WeightResult));
  return {weights,maxLoadG:loadG,withinLimit:options.withinLimit??true,score:{dragMN:dragN*1000,rollDeg,maxLoadG:loadG,failures:(options.sinks??0)+(options.capsizes??0)}} as ModelResult;
}

afterAll(()=>finish('simulation'));
describe('A081–A100 independent wave and ranking audit',()=>{
  it('A081 spectrum carries the prescribed significant-wave variance',()=>{
    const h=.008,c=seaComponents(h,.45,G);
    const actual=c.reduce((s,x)=>s+x.amp*x.amp/2,0);
    expect(benchmark({id:'A081',category,name:'Bretschneider component variance m0 = Hs²/16',expected:h*h/16,actual,absTolerance:1e-17,unit:'m²',severity:'info',note:'Checks energy normalization only, not the accuracy of hull response.'})).toBe(true);
  });
  it('A082 all components satisfy deep-water linear dispersion',()=>{
    const c=seaComponents(.008,.45,G);
    const actual=Math.max(...c.map(x=>Math.abs(G*x.k-x.omega*x.omega)/(x.omega*x.omega)));
    expect(benchmark({id:'A082',category,name:'Maximum deep-water dispersion residual',expected:0,actual,absTolerance:1e-14,unit:'relative',severity:'info',note:'ω² = gk is an independent linear-wave identity.'})).toBe(true);
  });
  it('A083 identical test inputs produce identical sea phases',()=>{
    const a=JSON.stringify(seaComponents(.008,.45,G)),b=JSON.stringify(seaComponents(.008,.45,G));
    expect(check({id:'A083',category,name:'Reproducible sea realization across models',expected:true,actual:a===b,passed:a===b,severity:'info'})).toBe(true);
  });
  it('A084 wave ramp starts at zero and reaches the prescribed cosine',()=>{
    const c={amp:.003,omega:4,k:16/G,phase:.31};
    const run={comps:[c],beam:true,U:0,ramp:1.2};
    const error=Math.max(Math.abs(elevation(run,.03,0)),Math.abs(elevation(run,.03,1.2)-c.amp*Math.cos(c.k*.03-c.omega*1.2+c.phase)));
    expect(benchmark({id:'A084',category,name:'Zero-start and completed wave-ramp absolute error',expected:0,actual:error,absTolerance:1e-15,unit:'m',severity:'info'})).toBe(true);
  });
  it('A085 head-wave encounter includes the forward-speed frequency shift',()=>{
    const c={amp:.003,omega:4,k:16/G,phase:.31},U=.4,xi=.03,t=.37;
    const expected=c.amp*Math.cos(c.k*xi+(c.omega+c.k*U)*t+c.phase);
    expect(benchmark({id:'A085',category,name:'Head-sea encounter elevation',expected,actual:elevation({comps:[c],beam:false,U,ramp:0},xi,t),absTolerance:1e-15,unit:'m',severity:'info'})).toBe(true);
  });
  it('A086 calm-water mean buoyancy equals the actual weight',()=>{
    const r=calmRun();
    expect(benchmark({id:'A086',category,name:'Calm-water buoyancy midpoint',expected:mass*G,actual:(r.buoyMin+r.buoyMax)/2,relTolerance:.001,unit:'N',severity:'high',note:'Physical equilibrium reference mg; does not validate wave-force extrema.'})).toBe(true);
  });
  it('A087 calm-water seeded roll decays after the measurement delay',()=>{
    const r=calmRun();
    expect(benchmark({id:'A087',category,name:'Residual calm roll after five peak periods',expected:0,actual:r.maxRollDeg,absTolerance:.05,unit:'deg',severity:'medium',note:'Simulation starts with an imposed 0.5° perturbation rather than perfect rest.'})).toBe(true);
  });
  it('A088 stable natural roll period matches the stated inertia/stiffness model',()=>{
    const expected=2*Math.PI*.38*cols.B/Math.sqrt(G*gm);
    expect(benchmark({id:'A088',category,name:'Positive-GM roll period from I44/(mg GM)',expected,actual:setup.naturalPeriods.roll,relTolerance:1e-12,unit:'s',severity:'info',note:'Verifies this assumed radius of gyration model only; actual inertia is not supplied by the STL.'})).toBe(true);
  });
  it('A089 an unstable negative-GM setup should not report a stable natural period',()=>{
    const unstable=makeSetup(cols,mass,.06,RHO,G,{...hydro,GM:-.035},.08);
    const stablePeriod=unstable!==null&&Number.isFinite(unstable.naturalPeriods.roll)&&unstable.naturalPeriods.roll>0;
    expect(check({id:'A089',category,name:'Negative-GM natural-period applicability guard',expected:'Rejected or period marked unavailable',actual:stablePeriod?`Positive period ${unstable!.naturalPeriods.roll} s`:'Unavailable',passed:!stablePeriod,severity:'medium',kind:'applicability criterion',note:'makeSetup clamps restoring stiffness to 0.02×beam to choose damping/time step. Main analysis separately labels negative GM unstable; this is an internal diagnostic issue, not evidence that the UI claims the hull is stable.'})).toBe(true);
  });
  it('A090 explicitly requested simulation duration must not be silently shortened',()=>{
    const periods=1000,tp=.45,r=simulate(setup,0,tp,true,0,periods);
    expect(benchmark({id:'A090',category,name:'Requested versus completed integration duration',expected:periods*tp,actual:r.steps*r.dt,absTolerance:r.dt,unit:'s',severity:'medium',kind:'numerical integrity criterion',note:'Public simulate(periods) silently caps at 30,000 steps; this test requests 1,000 periods, beyond the default 40.'})).toBe(true);
  });
  it('A091 wave roll is stable under fourfold time-step refinement',()=>{
    const base=waveRun();
    // Only the heave-period diagnostic is reduced to force a smaller dt. Physical forces,
    // mass/inertia, roll period, nonlinear damping and the sea remain unchanged.
    const refinedSetup={...setup,naturalPeriods:{...setup.naturalPeriods,heave:base.dt*25/4}};
    const fine=simulate(refinedSetup,.004,.45,true,0,20);
    expect(benchmark({id:'A091',category,name:'Maximum roll: base versus fourfold finer time step',expected:fine.maxRollDeg,actual:base.maxRollDeg,relTolerance:.05,unit:'deg',severity:'high',kind:'time-step convergence',note:`dt base=${base.dt}s, refined=${fine.dt}s. A passing comparison verifies one benign numerical case, not physical wave-response accuracy.`})).toBe(true);
  });
  it('A092 a run with no measured steps must not return plausible force extrema',()=>{
    // Valid positive finite public speed, although physically far beyond the method range.
    // A robust application must reject this condition or mark its statistics unavailable.
    const tp=.45,r=simulate(setup,.004,tp,false,1000,40);
    const observed=r.steps*r.dt>=5*tp;
    const unavailable=!Number.isFinite(r.buoyMin)||!Number.isFinite(r.buoyMax);
    expect(check({id:'A092',category,name:'Unobserved measurement-window statistics are withheld',expected:'Measured window or unavailable force extrema',actual:`duration=${r.steps*r.dt}s; measurement starts=${5*tp}s; buoyancy=[${r.buoyMin},${r.buoyMax}]N`,passed:observed||unavailable,severity:'medium',kind:'input-domain / numerical integrity',note:'Speed1000m/s is deliberately out of scope; the UI has no upper speed limit. The important failure is the missing domain guard and synthetic mg fallback when no post-ramp samples exist.'})).toBe(true);
  });
  it('A093 identical designs receive identical scores and tied placement',()=>{
    const rows=rankModels([{name:'A',result:model(.01,4,500)},{name:'B',result:model(.01,4,500)}]);
    expect(check({id:'A093',category,name:'Identical-candidate ranking tie',expected:'Both place1, equal finite score',actual:rows.map(x=>`${x.name}:${x.place}:${x.total}`).join('; '),passed:rows.every(x=>x.place===1&&Number.isFinite(x.total))&&rows[0].total===rows[1].total,severity:'info'})).toBe(true);
  });
  it('A094 category scores are invariant to common drag-unit rescaling',()=>{
    const base=rankModels([{name:'A',result:model(.01,4,500)},{name:'B',result:model(.02,5,600)}]);
    const scaled=rankModels([{name:'A',result:model(10,4,500)},{name:'B',result:model(20,5,600)}]);
    const actual=Math.max(...base.map(x=>Math.abs(x.total-scaled.find(y=>y.name===x.name)!.total)));
    expect(benchmark({id:'A094',category,name:'Common drag-unit factor leaves normalized score unchanged',expected:0,actual,absTolerance:1e-12,unit:'points',severity:'info'})).toBe(true);
  });
  it('A095 an over-limit hull cannot win an eligibility-constrained contest',()=>{
    const rows=rankModels([{name:'Eligible',result:model(.02,5,500)},{name:'Oversized',result:model(.01,2,1000,{withinLimit:false})}]);
    const oversized=rows.find(x=>x.name==='Oversized');
    const passed=!oversized||oversized.place>1||oversized.total===0;
    expect(check({id:'A095',category,name:'220mm size eligibility is enforced in placement',expected:'Oversized hull excluded or disqualified',actual:`${rows[0].name} wins with${rows[0].total}points`,passed,severity:'high',kind:'competition eligibility criterion',note:'rankModels never reads ModelResult.withinLimit. UI separately marks oversize dimensions, but ranking does not enforce that stated size rule.'})).toBe(true);
  });
  it('A096 one sunk load applies the advertised one-third score penalty',()=>{
    const row=rankModels([{name:'One load sinks',result:model(.01,4,500,{sinks:1})}])[0];
    expect(benchmark({id:'A096',category,name:'Single sunk-load total-score factor',expected:100*2/3,actual:row.total,relTolerance:1e-12,unit:'points',severity:'info',note:'This verifies the documented penalty for a static sinking failure, distinct from wave capsize.'})).toBe(true);
  });
  it('A097 one wave-capsized load applies the same advertised one-third penalty',()=>{
    const row=rankModels([{name:'One wave load capsizes',result:model(.01,4,500,{capsizes:1})}])[0];
    expect(benchmark({id:'A097',category,name:'Single wave-capsize load total-score penalty',expected:100*2/3,actual:row.total,relTolerance:1e-12,unit:'points',severity:'high',kind:'documented scoring behaviour',note:'Wave capsize sets failures, but validFrac counts only floats&&stable. With this sole candidate every category still normalizes to100 despite one capsize failure.'})).toBe(true);
  });
  it('A098 zero-resistance candidates must not produce NaN contest scores',()=>{
    const rows=rankModels([{name:'A',result:model(0,4,500)},{name:'B',result:model(0,5,600)}]);
    const passed=rows.every(x=>Number.isFinite(x.scoreDrag)&&Number.isFinite(x.total));
    expect(check({id:'A098',category,name:'Zero-drag normalization is finite',expected:'Finite scores or explicit unavailable category',actual:rows.map(x=>`${x.name}:drag=${x.scoreDrag},total=${x.total}`).join('; '),passed,severity:'medium',kind:'numerical integrity',note:'bestDrag/drag is0/0. Zero speed is a meaningful force limit; UI currently imposes a0.01m/s minimum but public engine/conditions do not enforce it.'})).toBe(true);
  });
  it('A099 adding an unrelated competitor should not reverse the same A/B design comparison',()=>{
    const A={name:'A',result:model(.01,10,500)},B={name:'B',result:model(.02,2,500)},C={name:'C',result:model(.2,.1,500)};
    const pair=rankModels([A,B]),field=rankModels([A,B,C]);
    const difference=(rows:ReturnType<typeof rankModels>)=>rows.find(x=>x.name==='A')!.total-rows.find(x=>x.name==='B')!.total;
    const before=difference(pair),after=difference(field),passed=Math.sign(before)===Math.sign(after);
    expect(check({id:'A099',category,name:'A/B ranking robustness to a third normalization reference',expected:'A/B order unchanged',actual:`A−B before=${before}points; after=${after}points`,passed,severity:'medium',kind:'scoring-design sensitivity criterion',note:'This is an inherent consequence of best-candidate normalization, not a coding error against the stated formula. It shows scores are relative to the candidate field and are not intrinsic design-quality measurements.'})).toBe(true);
  });
  it('A100 one nonfinite prediction must not poison all other candidates',()=>{
    const rows=rankModels([{name:'Valid',result:model(.01,4,500)},{name:'Invalid drag prediction',result:model(NaN,3,600)}]);
    const valid=rows.find(x=>x.name==='Valid')!;
    expect(check({id:'A100',category,name:'Nonfinite-result isolation in leaderboard',expected:'Valid candidate retains a finite total',actual:`Valid total=${valid.total}; drag score=${valid.scoreDrag}`,passed:Number.isFinite(valid.total)&&Number.isFinite(valid.scoreDrag),severity:'high',kind:'numerical integrity',note:'Math.min includes NaN from any floats&&stable candidate, contaminating bestDrag and every competitor score.'})).toBe(true);
  });
});
